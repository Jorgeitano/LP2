﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            colorDialog1 = new ColorDialog();
            lblAltura = new Label();
            lblIMC = new Label();
            mskbxPeso = new MaskedTextBox();
            mskbxAltura = new MaskedTextBox();
            txtIMC = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            txtClassIMC = new TextBox();
            txtGrauIMC = new TextBox();
            lblGrau = new Label();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(65, 57);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(92, 25);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso atual";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(65, 106);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(65, 198);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(44, 25);
            lblIMC.TabIndex = 2;
            lblIMC.Text = "IMC";
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(172, 57);
            mskbxPeso.Mask = "000.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(150, 31);
            mskbxPeso.TabIndex = 3;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Location = new Point(172, 106);
            mskbxAltura.Mask = "0.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(150, 31);
            mskbxAltura.TabIndex = 4;
            mskbxAltura.Validated += mskbxAltura_Validated;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(159, 192);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(66, 31);
            txtIMC.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(58, 256);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(210, 256);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(442, 256);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // txtClassIMC
            // 
            txtClassIMC.Enabled = false;
            txtClassIMC.Location = new Point(252, 192);
            txtClassIMC.Name = "txtClassIMC";
            txtClassIMC.Size = new Size(158, 31);
            txtClassIMC.TabIndex = 9;
            // 
            // txtGrauIMC
            // 
            txtGrauIMC.Enabled = false;
            txtGrauIMC.Location = new Point(486, 192);
            txtGrauIMC.Name = "txtGrauIMC";
            txtGrauIMC.Size = new Size(48, 31);
            txtGrauIMC.TabIndex = 10;
            // 
            // lblGrau
            // 
            lblGrau.AutoSize = true;
            lblGrau.Location = new Point(428, 164);
            lblGrau.Name = "lblGrau";
            lblGrau.Size = new Size(162, 25);
            lblGrau.TabIndex = 11;
            lblGrau.Text = "Grau de obesidade";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(632, 341);
            Controls.Add(lblGrau);
            Controls.Add(txtGrauIMC);
            Controls.Add(txtClassIMC);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtIMC);
            Controls.Add(mskbxAltura);
            Controls.Add(mskbxPeso);
            Controls.Add(lblIMC);
            Controls.Add(lblAltura);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private ColorDialog colorDialog1;
        private Label lblAltura;
        private Label lblIMC;
        private MaskedTextBox mskbxPeso;
        private MaskedTextBox mskbxAltura;
        private TextBox txtIMC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private TextBox txtClassIMC;
        private TextBox txtGrauIMC;
        private Label lblGrau;
    }
}
