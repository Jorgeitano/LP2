﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercico1>().Count() > 0)
            {
                Application.OpenForms["FrmExercico1"].BringToFront();
            }
            else
            {
                FrmExercico1 frmExercicio1 = new FrmExercico1();
                frmExercicio1.MdiParent = this;
                frmExercicio1.WindowState = FormWindowState.Maximized;
                frmExercicio1.Show();
            }
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Frm_Exercicio2>().Count() > 0)
            {
                Application.OpenForms["Frm_Exercicio2"].BringToFront();
            }
            else
            {
                Frm_Exercicio2 frmExercicio2 = new Frm_Exercicio2();
                frmExercicio2.MdiParent = this;
                frmExercicio2.WindowState = FormWindowState.Maximized;
                frmExercicio2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Frm_Exercicio3>().Count() > 0)
            {
                Application.OpenForms["Frm_Exercicio3"].BringToFront();
            }
            else
            {
                Frm_Exercicio3 frmExercicio3 = new Frm_Exercicio3();
                frmExercicio3.MdiParent = this;
                frmExercicio3.WindowState = FormWindowState.Maximized;
                frmExercicio3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 frmExercicio4 = new FrmExercicio4();
                frmExercicio4.MdiParent = this;
                frmExercicio4.WindowState = FormWindowState.Maximized;
                frmExercicio4.Show();
            }
        }
    }
}
