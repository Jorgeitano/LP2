﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] tamanho = new int[10];
            int qnt,t=0;
            string[] nomes = new string[10];
            string aux = "";

            lstBoxNomes.Items.Clear();
            aux = Interaction.InputBox($"quantos nomes?", "Entrada de dados");
            if (!int.TryParse(aux, out qnt) || qnt > 10)
            {
                MessageBox.Show("Numero invalido");
            }
            else
            {
                for (int i = 0; i < qnt; i++)
                {
                    aux = Interaction.InputBox($"Digite o {i + 1} nome", "Entrada de dados");
                    for (int j = 0; j < aux.Length; j++)
                    {
                        if (aux[j] != ' ')
                        {
                            tamanho[t] += 1;
                        }
                    }

                    lstBoxNomes.Items.Add($"nome: {aux} tem {tamanho[t]} caracteres");
                    t++;
                }
            }
        }
    }
}
