﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class FrmExercico1 : Form
    {
        int contar=0;
        public FrmExercico1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int i;
            string frase;
            frase = rtxtFrase.Text;
            contar = 0;
            for (i = 0; i < frase.Length; i++)
            {
                if (frase[i]==' ')
                    contar++;
            }
            MessageBox.Show($"Quantidade de espaço: {contar}");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int i;
            string frase;
            contar = 0;
            frase = rtxtFrase.Text;
            for (i = 0; i < frase.Length; i++)
            {
                if (frase[i] == 'R' || frase[i] == 'r')
                    contar++;
            }
            MessageBox.Show($"Quantidade de letras R ou r: {contar}");
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int i, contar = 0;
            string frase;

            frase = rtxtFrase.Text;

            for (i = 0; i < frase.Length - 1; i++)
            {
                if (frase[i] == frase[i + 1] && frase[i] != ' ')
                {
                    contar++;
                }
            }

            MessageBox.Show($"Quantidade de letras repetidas juntas: {contar}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rtxtFrase.Text = "";
            rtxtFrase.Focus();
        }
    }
}
