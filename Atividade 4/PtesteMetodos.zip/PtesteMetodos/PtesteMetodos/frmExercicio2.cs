﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPalavra1.Clear();
            txtPalavra2.Clear();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (txtPalavra1.Text == txtPalavra2.Text)
                MessageBox.Show("As palavras são iguais!");
            else
                MessageBox.Show("As palavras são diferentes!"); 
        }

        private void btnPrimeiroSegundo_Click(object sender, EventArgs e)
        {
            string p1 = txtPalavra1.Text;
            string p2 = txtPalavra2.Text;

            int meio = p2.Length / 2;

            string resultado = p2.Insert(meio, p1);

            txtPalavra2.Text = resultado;
        }

        private void btnPrimeiroAst_Click(object sender, EventArgs e)
        {
            string p1 = txtPalavra1.Text;

            int meio = p1.Length / 2;

            string resultado = p1.Insert(meio, "**");

            txtPalavra1.Text = resultado;
        }
    }
}
