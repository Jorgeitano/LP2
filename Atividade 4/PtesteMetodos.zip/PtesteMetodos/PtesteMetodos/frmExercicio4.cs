﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContNum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < rickTxtFrm4.Text.Length)
            {
                if (char.IsNumber(rickTxtFrm4.Text[posicao]))
                {
                    contaNum++;
                }
                posicao++;
            }


            MessageBox.Show($"Quantidade de números: {contaNum} números" );
        }

        private void btnPrimeiraBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rickTxtFrm4.Text.Length; i++) 
            {
                if (char.IsWhiteSpace(rickTxtFrm4.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            if (posicao > 0)
            {
                MessageBox.Show($"O primeiro caracter em branco está na posicão {posicao}");
            }
            else
                MessageBox.Show("Não há caracteres em branco");
    
        }
        private void btnContLetra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach (char  c in rickTxtFrm4.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }

            }
            MessageBox.Show($"A frase tem {contaLetra} letras");
        }
    }
}
