﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[,] respostas = new char[2,10];
            char[] gabarito = new char[10] {'A', 'B', 'C','D', 'E', 'A', 'B', 'C', 'D', 'E' };
            string aux = "";

            for (int i = 0; i < respostas.GetLength(0); i++)
            {
                for (int j = 0; j < respostas.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Aluno {i + 1}: Questão {j + 1} ", "Entrada de dados");
                    if (!char.TryParse(aux, out respostas[i, j]))
                    {
                        MessageBox.Show("Resposta invalida");
                        j--;
                    }
                    else
                        respostas[i, j] = char.ToUpper(respostas[i, j]);
                   
                }
            }

            for (int i = 0;i < respostas.GetLength(0); i++)
            {
                for (int j = 0;j < respostas.GetLength(1); j++)
                {
                    if (gabarito[j] == respostas[i, j])
                    {
                        lstBoxvetor.Items.Add($"O aluno {i + 1} acertou questão {j + 1} " +
                            $"era {gabarito[j]} escolheu {respostas[i, j]}");
                    }
                    else
                    {
                        lstBoxvetor.Items.Add($"O aluno {i + 1} errou questão {j + 1} " +
                            $"era {gabarito[j]} escolheu {respostas[i, j]}");
                    }
                }
            }
        }
    }
}
