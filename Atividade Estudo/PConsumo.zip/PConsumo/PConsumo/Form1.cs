﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void but_Click(object sender, EventArgs e)
        {
            double Pu = 0;
            const int SEmana = 4;
            const int SEtor = 5;
            double[] TotalR = new double[SEtor];
            double[] TotalL = new double[SEtor];


            double[,] Po = new double[SEtor, SEmana];

            string[] Pi = { "Produção", "Escritorio", "Refeitorio", "Limpeza", "Logistica" };

            for (int i = 0; i < SEtor; i++)
            {
                for (int j = 0; j < SEmana; j++)
                {
                    string aux = Interaction.InputBox($"Digite o água na semana {j + 1} no {Pi[i]}");
                    if (aux == "")
                    { return; }
                    if (!double.TryParse(aux, out Po[i,j]) || Po[i,j]<0)
                    {
                        MessageBox.Show("Numero invalido!");
                        j--;
                    }
                    else
                    {
                       
                        TotalL[i] += Po[i, j];
                        TotalR[i] = TotalL[i] * 0.01;
                    }
                   

                }
                
            }
            Lbox.Items.Clear();

            Lbox.Items.Add("resultado:");
            for (int i = 0; i < SEtor; i++)
            {
                Lbox.Items.Add(Pi[i] + " Gastou " + TotalL[i] +" Litros e R$"+ TotalR[i]);
            }
            
        }
    }
}
