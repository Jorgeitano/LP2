﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade1
{
    public partial class Form1 : Form
    {
        double n1, n2, resultado;

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(txtNum2.Text, out n2))
            {
                MessageBox.Show("Digite um número valido!");
                txtNum2.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (n1 + n2).ToString();
           
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (n1-n2).ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResultado.Text = (n1 * n2).ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (n2 == 0)
            {
                MessageBox.Show("Impossível dividir por 0");
                txtNum2.Focus();
            }
            else
            {
                txtResultado.Text = (n1 / n2).ToString();
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();    
            txtResultado.Clear();
            txtNum1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
            {
                return;
            }
            if(!double.TryParse(txtNum1.Text, out n1))
            {
                MessageBox.Show("Digite um número válido!");
                txtNum1.Focus();
            }
        }

    }
}
