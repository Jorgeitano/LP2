﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite um numero na poisiçao {i + 1}", "Entrada de dados");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Numero invalido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            aux = "";

            foreach (int i in vetor)
                aux += i + "\n";

            MessageBox.Show(aux);
        }

        private void Ex2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Beatriz");
            nomes.Add("Camila");
            nomes.Add("João");
            nomes.Add("Joana");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            nomes.Remove("Otávio");
            string aux = "";
            foreach(string i in nomes)
                aux += i + "\n";

            MessageBox.Show(aux);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            double media;
            string aux = "", medias ="";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Aluno {i + 1}: Prova {j + 1} ", "Entrada de dados");
                    if (!double.TryParse(aux, out notas[i,j]) || notas[i,j] > 10 || notas[i, j] < 0)
                    {
                        MessageBox.Show("Numero invalido");
                        j--;
                    }
                }
            }

            for (int i = 0; i < notas.GetLength(0); i++) 
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3.0;
                medias += "Aluno " + (i+1) + ": média " +  media + "\n";
            }

            MessageBox.Show(medias);

        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count()>0){
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0){
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.Show();
            }
        }
    }
}
