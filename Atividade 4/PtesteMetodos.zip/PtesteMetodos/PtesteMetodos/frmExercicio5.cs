﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }
        int num1 = 0;
        int num2 = 0;
        private void txtPalavra1_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtPalavra1.Text, out num1))
            {
                MessageBox.Show("Digite um número válido no campo 1.");
                e.Cancel = true;
            }
        }
        private void txtPalavra2_Validating(object sender, CancelEventArgs e)
        {
            if(!int.TryParse(txtPalavra2.Text, out num2))
            {
                MessageBox.Show("Digite um número válido no campo 2. ");
                
            }

        }
        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (num1 >= num2)
            {
                MessageBox.Show("O número 1 é menor que o número 2.");
                
            }

            Random rnd = new Random();
            int sorteado = rnd.Next(num1, num2 + 1);

            MessageBox.Show("Número sorteado: " + sorteado);
        }
    }
}
