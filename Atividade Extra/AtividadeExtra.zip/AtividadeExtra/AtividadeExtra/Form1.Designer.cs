﻿namespace AtividadeExtra
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxResultados = new System.Windows.Forms.ListBox();
            this.btnExecuta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxResultados
            // 
            this.listBoxResultados.FormattingEnabled = true;
            this.listBoxResultados.Location = new System.Drawing.Point(319, 81);
            this.listBoxResultados.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.listBoxResultados.Name = "listBoxResultados";
            this.listBoxResultados.Size = new System.Drawing.Size(215, 160);
            this.listBoxResultados.TabIndex = 0;
            this.listBoxResultados.SelectedIndexChanged += new System.EventHandler(this.listBoxResultados_SelectedIndexChanged);
            // 
            // btnExecuta
            // 
            this.btnExecuta.Location = new System.Drawing.Point(147, 81);
            this.btnExecuta.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnExecuta.Name = "btnExecuta";
            this.btnExecuta.Size = new System.Drawing.Size(121, 61);
            this.btnExecuta.TabIndex = 1;
            this.btnExecuta.Text = "Somar";
            this.btnExecuta.UseVisualStyleBackColor = true;
            this.btnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 398);
            this.Controls.Add(this.btnExecuta);
            this.Controls.Add(this.listBoxResultados);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxResultados;
        private System.Windows.Forms.Button btnExecuta;
    }
}

