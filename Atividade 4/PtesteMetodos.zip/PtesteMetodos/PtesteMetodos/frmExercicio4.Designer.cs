﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnPrimeiraBranco = new System.Windows.Forms.Button();
            this.btnContLetra = new System.Windows.Forms.Button();
            this.rickTxtFrm4 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnContNum
            // 
            this.btnContNum.Location = new System.Drawing.Point(214, 449);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(185, 49);
            this.btnContNum.TabIndex = 0;
            this.btnContNum.Text = "Contar Numeros";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.btnContNum_Click);
            // 
            // btnPrimeiraBranco
            // 
            this.btnPrimeiraBranco.Location = new System.Drawing.Point(405, 449);
            this.btnPrimeiraBranco.Name = "btnPrimeiraBranco";
            this.btnPrimeiraBranco.Size = new System.Drawing.Size(185, 49);
            this.btnPrimeiraBranco.TabIndex = 1;
            this.btnPrimeiraBranco.Text = "Localiza 1 Caracter em Branco";
            this.btnPrimeiraBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiraBranco.Click += new System.EventHandler(this.btnPrimeiraBranco_Click);
            // 
            // btnContLetra
            // 
            this.btnContLetra.Location = new System.Drawing.Point(596, 449);
            this.btnContLetra.Name = "btnContLetra";
            this.btnContLetra.Size = new System.Drawing.Size(185, 49);
            this.btnContLetra.TabIndex = 2;
            this.btnContLetra.Text = "Contar Letras";
            this.btnContLetra.UseVisualStyleBackColor = true;
            this.btnContLetra.Click += new System.EventHandler(this.btnContLetra_Click);
            // 
            // rickTxtFrm4
            // 
            this.rickTxtFrm4.Location = new System.Drawing.Point(214, 67);
            this.rickTxtFrm4.Name = "rickTxtFrm4";
            this.rickTxtFrm4.Size = new System.Drawing.Size(567, 330);
            this.rickTxtFrm4.TabIndex = 3;
            this.rickTxtFrm4.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(991, 603);
            this.Controls.Add(this.rickTxtFrm4);
            this.Controls.Add(this.btnContLetra);
            this.Controls.Add(this.btnPrimeiraBranco);
            this.Controls.Add(this.btnContNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnPrimeiraBranco;
        private System.Windows.Forms.Button btnContLetra;
        private System.Windows.Forms.RichTextBox rickTxtFrm4;
    }
}