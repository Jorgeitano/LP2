﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < (ladoB + ladoC)) && (ladoA > (Math.Abs(ladoB - ladoC))) &&
                (ladoB < (ladoA + ladoC)) && (ladoB > (Math.Abs(ladoA - ladoC))) &&
                (ladoC < (ladoA + ladoB)) && (ladoC > (Math.Abs(ladoA - ladoB))))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Equilátero");
                }
                else if (
                    (ladoA == ladoB) ||
                    (ladoA == ladoC) ||
                    (ladoB == ladoC)
                    )
                {
                    MessageBox.Show("Isóceles");
                }
                else
                    MessageBox.Show("Escaleno");
            }
            else
                MessageBox.Show("Não forma triangulo");
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out ladoB))
            {
                MessageBox.Show("Valor inválido");
                txtValorA.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out ladoC))
            {
                MessageBox.Show("Valor inválido");
                txtValorA.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            ladoA = 0;
            ladoB = 0;
            ladoC = 0;
        }
        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out ladoA)) 
                {
                MessageBox.Show("Valor inválido");
                txtValorA.Focus(); 
                }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
