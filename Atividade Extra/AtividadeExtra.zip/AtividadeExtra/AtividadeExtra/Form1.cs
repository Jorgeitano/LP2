﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace AtividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[7, 5];
            double[] Totalpordia = new double[7];
            double TotalGeral = 0;

            string[] dias = { "Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado" };

            listBoxResultados.Items.Clear();

            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    string valor = Interaction.InputBox(
                        $"Digite o valor do produto {j + 1} para {dias[i]}:",
                        "Entrada de dados",
                        "0"
                );
                    if (!double.TryParse(valor, out matriz[i, j]))
                    {
                        matriz[i, j] = 0;
                    }
                }
            }

            for (int i = 0; i < 7; i++)
            {
                double somaLinha = 0;
                for (int j = 0; j < 5; j++)
                {
                    somaLinha += matriz[i, j];
                }
                Totalpordia[i] = somaLinha;
            }

            for (int i = 0; i < 7; i++)
            {
                TotalGeral += Totalpordia[i];
            }
            listBoxResultados.Items.Clear();
            listBoxResultados.Items.Add(" Total por dia ");
            for (int i = 0; i < 7; i++)
            {
                listBoxResultados.Items.Add($"{dias[i]}: R$ {Totalpordia[i]:F2}");
            }

            listBoxResultados.Items.Add("");
            listBoxResultados.Items.Add(" Total geral");
            listBoxResultados.Items.Add($"Total geral: R$ {TotalGeral:F2}");
        }




        private void listBoxResultados_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
